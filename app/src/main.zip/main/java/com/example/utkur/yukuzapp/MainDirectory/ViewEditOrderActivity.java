package com.example.utkur.yukuzapp.MainDirectory;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.utkur.yukuzapp.MainDirectory.CreateOrder.Deliveries;
import com.example.utkur.yukuzapp.Module.PostOrder;
import com.example.utkur.yukuzapp.R;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ViewEditOrderActivity extends AppCompatActivity implements OnMapReadyCallback {
    private String TAG = "ViewOrderActivity";
    private PostOrder order;
    @BindView(R.id.view_order_map)
    MapView map_view;
    private GoogleMap mMap;
    LatLng source;
    LatLng destination;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_edit_order);
        ButterKnife.bind(this);
        int id = getIntent().getExtras().getInt("id");
        int position = getIntent().getExtras().getInt("pos");
        Log.d(TAG, "onCreate: " + position);
        order = Deliveries.postOrders.get(position);
        float la = Float.parseFloat(order.getSource_address().split("/")[0]);
        float ln = Float.parseFloat(order.getSource_address().split("/")[1]);
        source = new LatLng(la, ln);
        la = Float.parseFloat(order.getDestination_address().split("/")[0]);
        ln = Float.parseFloat(order.getDestination_address().split("/")[1]);
        destination = new LatLng(la, ln);
        if (map_view != null) {
            map_view.onCreate(null);
            map_view.onResume();
            map_view.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
//        mMap.addMarker()
    }
}
