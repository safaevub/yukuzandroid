package com.example.utkur.yukuzapp.Authentication.Registration;

/**
 * Created by Muhammadjon on 10/27/2017.
 */

public interface RegCommunicator {
    boolean onSubmit();
}
