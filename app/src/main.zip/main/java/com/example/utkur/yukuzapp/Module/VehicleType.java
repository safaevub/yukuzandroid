package com.example.utkur.yukuzapp.Module;

/**
 * Created by Muhammadjon on 11/5/2017.
 */

public class VehicleType {
    private int id;
    private String title;
    private String description;

    public VehicleType(int id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return getTitle();
    }
}
